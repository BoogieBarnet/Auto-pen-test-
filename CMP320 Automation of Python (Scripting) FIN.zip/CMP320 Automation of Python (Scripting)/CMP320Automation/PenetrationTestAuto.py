import nmap
from prettytable import PrettyTable
from datetime import datetime
from docx import Document
import os
import subprocess
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException, TimeoutException
from selenium.webdriver.common.action_chains import ActionChains
import time


def clear_screen():
    # For Windows
    if os.name == 'nt':
        _ = os.system('cls')
    # For Linux and MacOS
    else:
        _ = os.system('clear')

# Signature import that should be on everything.
ascii_art = ""
with open("startup2.txt", "r") as file:
    ascii_art = file.read()
print(ascii_art)

# Printing it's by me
print("Penetration test automation by Jack Barnet")
#simple menu 
def display_menu(ip_addr):
    print("1. Nmap Scanning")
    print("2. Directory Buster")
    print("3. Nessus")
    print("4. Report Writing")
    print("5. Get Results")
    print("9. Exit")
    print("\nCurrent IP Address:", ip_addr) #pasting the ip used is important


def option_1(ip_addr):
    clear_screen()
    return nmapscan(ip_addr)


def nmapscan(ip_addr):
    print("You selected Option 1")
    print("The IP =", ip_addr)

    print("What Nmap scan:") #select scan choice as there are multiple options
    print("1. Quick Scan")
    print("2. Full Scan")
    print("3. Version Detection")
    print("4. OS Detection") 
    print("5. Aggressive Scan")
    scan_type = input("Enter your choice (1-5): ")

    if scan_type == "1":
        scan_args = "-T4 -F"  # Quick scan
    elif scan_type == "2":
        scan_args = "-T4 -A"  # Full Scan
    elif scan_type == "3":
        scan_args = "-sV"  # version Detection
    elif scan_type == "4":
        scan_args = "-O"  # OS Detection
    elif scan_type == "5":
        scan_args = "-A"  # Aggressive Scan
    else:
        print("Invalid input. Defaulting to Quick Scan.")
        scan_args = "-T4 -F"  # Default to Quick Scan

    nm = nmap.PortScanner()
    nm.scan(ip_addr, arguments=scan_args)
    #most of the useful findings from nmap from its documentation 
    table = PrettyTable(["Port", "Protocol", "Service", "Version", "State", "Reason", "Confidence", "CPE"])
	#info found in nmap
    if 'tcp' in nm[ip_addr]:
        for port, info in nm[ip_addr]['tcp'].items():
            table.add_row([
                port,
                info.get('protocol', '-'),
                info.get('name', '-'),
                info.get('version', '-'),
                info.get('state', '-'),
                info.get('reason', '-'),
                info.get('conf', '-'),
                info.get('cpe', '-')
            ])
    else:
        print(f"No TCP ports found for host {ip_addr}")

    print("Nmap Scan Results:")
    print(table)
    input("Press Enter to continue...")
    return table


def option_2(ip_addr):
    print("You selected Option 2")
    print("You have selected Directory Buster")
    print("Running Dirb scan on IP:", ip_addr) #pasting ip again so the user knows what one

    wordlists_dir = ""  # Directory containing wordlists this is incase it changes 
    common_wordlists = [
        "common.txt" # this can be changed dependent on what one i wnat to scan for i.e big, small, common
    ]

    cmds = []
    for wordlist in common_wordlists:
        cmd = ["dirb", "http://" + ip_addr, wordlists_dir + wordlist] # possibly have to remove https:// after (this took ages to workout why it wasnt working.)
        cmds.append(cmd)
        print("Command:", " ".join(cmd)) # pastes the command so the user knows whats being scanned 

    for cmd in cmds:
        result = subprocess.run(cmd, capture_output=True, text=True)
        if result.returncode == 0:
            print("Dirb Scan Results:")
            lines = result.stdout.splitlines()
            found_domains = []
            for line in lines:
                if "==> DIRECTORY" in line: #pastes just the found directories
                    domain = line.split()[-1]
                    found_domains.append(domain)

            if found_domains:
                print("Domains Found:")
                for domain in found_domains:
                    print(domain)

            input("Press Enter to continue...")
            return found_domains


def option_3(ip_addr):
    print("You selected Option 3")
    # code here
    nessus_scan(ip_addr)


def nessus_scan(ip_addr):
    
    print("The IP =", ip_addr)
    
    # Prompt user for the scan name for furture use
    scan_name = input("Enter the name for the scan: ")
    
    # Create Chrome options
    chrome_options = webdriver.ChromeOptions()
    
    # Add options to ignore ssl certificate errors and disable web security when booting up chrome had a page saying it was unsafe
    chrome_options.add_argument("--ignore-certificate-errors")
    chrome_options.add_argument("--ignore-ssl-errors")
    chrome_options.add_argument("--disable-web-security")
    
    # Set Chrome to run but show no window 
    #chrome_options.add_argument("--headless")
    
    # Set the path to Chromedriver had to download chrome as firefox was blocking due to CSP
    chromedriver_path = "/home/kali/Desktop/CMP320Automation/chromedriver"
    
    # Create Chrome WebDriver with service and options
    driver = webdriver.Chrome(executable_path=chromedriver_path, options=chrome_options)
    
    try:
        # Open the Nessus web interface with Chrome
        driver.get("https://localhost:8834/#")  # Use HTTPS i had HTTP previously didnt work
        # Wait for elements to be clickable
        wait = WebDriverWait(driver, 10) 
        
        # Find and fill in username
        username_input = wait.until(EC.visibility_of_element_located((By.CSS_SELECTOR, ".login-username")))
        username_input.send_keys("admin")
        
        # Find and fill in password
        password_input = driver.find_element(By.CSS_SELECTOR, ".login-password")
        password_input.send_keys("hacklab")
        
        # Click the login button
        login_button = driver.find_element(By.CSS_SELECTOR, "button")
        login_button.click()
        
        # Wait for the dashboard to load
        time.sleep(5)  # Adjustable depending on load speed (this works fine for my laptop)
        
        # Click on "New Scan"
        new_scan_link = wait.until(EC.element_to_be_clickable((By.LINK_TEXT, "New Scan")))
        new_scan_link.click()
        time.sleep(5) 
        
        # Click on "Advanced" Scan
        advanced_scan_button = wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, ".advanced")))
        advanced_scan_button.click()
        time.sleep(5) 
        
        # Fill in scan name
        scan_name_input = wait.until(EC.visibility_of_element_located((By.CSS_SELECTOR, ".form-group:nth-child(1) .required")))
        scan_name_input.send_keys(scan_name)
        time.sleep(5) 
        
        # Fill in IP address
        ip_address_input = driver.find_element(By.CSS_SELECTOR, ".form-group:nth-child(5) .required")
        ip_address_input.send_keys(ip_addr)
        time.sleep(5) 
        
        # Click the Save button
        save_button = driver.find_element(By.CSS_SELECTOR, ".primary-action")
        save_button.click()
        time.sleep(5) 
        
        # Wait for the "Launch" button to be clickable
        launch_button = wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, ".launch")))
        launch_button.click()
        
        print("Scan is running. Waiting for completion...")
        
       
        # Wait for the scan to complete (adjust time as needed)
        time.sleep(500)  
        #cant get it to close once its completed :( 
    
        # 2 errors found on stack over flow to point in the direction of erros when i was testing 
    except NoSuchElementException as e:
        print("finding error", e)

    except TimeoutException:
        print("Timeout occurred.")
        input("Press Enter to continue...")
  #Using Selenium IDE and then record walk through really helped with this highly recomend :) 
   

def option_4(ip_addr, table, dirb_results):
    print("You selected Option 4")
    if table is None:
        print("Please run Nmap scan (Option 1) first to generate results.")
    else:
        create_report(ip_addr, table, dirb_results)
    input("Press Enter to continue...")


def create_report(ip_addr, table, dirb_results): 
    doc = Document() #first initilization 
    doc.add_heading('Penetration Test Report', 0)
#standard time stamp code from stackoverflow 
    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    doc.add_paragraph(f"Report auto generated  {timestamp}")


	#standard docx liberary usage from class 
    doc.add_heading('Nmap Scan Results', level=1)
    doc.add_paragraph(f"Target IP: {ip_addr}")
    doc.add_paragraph("Nmap Scan Results:")
    doc.add_paragraph(str(table))
    
	#catch error if dirb isnt ran 
    if dirb_results is not None:
        doc.add_heading('Dirb Scan Results', level=1)
        doc.add_paragraph(f"Target IP: {ip_addr}")
        doc.add_paragraph("Domains Found:")
        for domain in dirb_results:
            doc.add_paragraph(domain)

    doc_filename = f"Penetration_Test_Report_{ip_addr}_{timestamp}.docx"
    doc.save(doc_filename)
    print(f"Report saved as Word document: {doc_filename}")

def option_5(driver, wait):
    print("You selected Option 5")
    get_results(driver, wait)
    
#Pretty much copy and paste from above Selenium IDE walkthrough helped alot with this too    
def get_results():
    try:
        # Create Chrome options
        chrome_options = webdriver.ChromeOptions()
         # Set Chrome to run but show no window 
         #chrome_options.add_argument("--headless")
        # Add options to ignore SSL certificate errors and disable web security
        chrome_options.add_argument("--ignore-certificate-errors")
        chrome_options.add_argument("--ignore-ssl-errors")
        chrome_options.add_argument("--disable-web-security")
        
        #Set the path to Chromedriver
        chromedriver_path = "/home/kali/Desktop/CMP320Automation/chromedriver"
        
        #reate Chrome WebDriver with service and options
        driver = webdriver.Chrome(executable_path=chromedriver_path, options=chrome_options)
        
        # Wait for elements to be clickable
        wait = WebDriverWait(driver, 10)
        
        #Open the Nessus web interface with Chrome
        driver.get("https://localhost:8834/#")  # Use HTTPS
        
        # Find and fill in username
        username_input = wait.until(EC.visibility_of_element_located((By.CSS_SELECTOR, ".login-username")))
        username_input.send_keys("admin")
        time.sleep(2)
        
        # Find and fill in password
        password_input = driver.find_element(By.CSS_SELECTOR, ".login-password")
        password_input.send_keys("hacklab")
        time.sleep(2)
        
        #Click the login button
        login_button = driver.find_element(By.CSS_SELECTOR, "button")
        login_button.click()
        time.sleep(5)
        time.sleep(5)
    
        
        # Find and click on the first scan (Current issue is having to delete the old scans so it picks the right one mention in furture work) 
        first_scan = wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, ".odd > .scan-visible-name")))
        first_scan.click()
        time.sleep(5)
        
        # Generate scan report
        generate_report_button = wait.until(EC.element_to_be_clickable((By.ID, "generate-scan-report")))
        generate_report_button.click()
        time.sleep(5)
        
        # Click on HTML button
        add_tip_button = wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, ".add-tip:nth-child(2)")))
        add_tip_button.click()
        time.sleep(2)
        
        #Click on Toggle All button
        toggle_all_button = wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, ".checked > .toggle")))
        toggle_all_button.click()
        time.sleep(2)
        
        # Click on Save button
        save_button = wait.until(EC.element_to_be_clickable((By.ID, "report-save")))
        save_button.click()
        time.sleep(5)
        
        input("Press Enter to continue...")
        
     # 2 errors found on stack over flow to point in the direction of erros when i was testing 
    except NoSuchElementException as e:
        print("finding error", e)

    except TimeoutException:
        print("Timeout occurred.")
        input("Press Enter to continue...")
        
 
            
# Declaring each possible variable for the report writing so it can be put in the doc even if its not been used
ip_addr = input("Enter the target IP address: ")
dirb_results = None
table = None 


while True:
    clear_screen()
    display_menu(ip_addr)
    choice = input("Enter your choice (1-5 or 9): ")

    if choice == "1":
        table = option_1(ip_addr)
    elif choice == "2":
        dirb_results = option_2(ip_addr)
    elif choice == "3":
        option_3(ip_addr)
    elif choice == "4":
        option_4(ip_addr, table, dirb_results)
    elif choice == "5":
        get_results()
    elif choice == "9":
        print("Exiting the program. Goodbye!")
        break
    else:
        print("Invalid. Please enter a number between 1 and 5 or 9 to quit.")


#few notes future work

#get the 
